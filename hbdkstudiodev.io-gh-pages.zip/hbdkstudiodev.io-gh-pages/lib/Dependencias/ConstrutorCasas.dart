

class ConstrutorCasas{

  final dynamic nome;
  final dynamic caminhoAnimacao;
  final dynamic pontos;


   ConstrutorCasas({

    required this.pontos,
    required this.nome,
    required this.caminhoAnimacao,
    // required this.animacao,

  });

}
