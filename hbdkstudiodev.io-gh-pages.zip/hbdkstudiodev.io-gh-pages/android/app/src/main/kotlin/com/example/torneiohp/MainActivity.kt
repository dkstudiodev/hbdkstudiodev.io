package com.example.torneiohp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
